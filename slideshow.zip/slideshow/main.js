const slideshow = document.querySelector('.slideshow')
const slideshowimage = document.querySelectorAll('.slideshow img')
const nextbtn = document.querySelector('#next')
const prevbtn = document.querySelector('#prev')
const size = slideshow.clientWidth
console.log(size);
let counter = 1

nextbtn.addEventListener('click', () => {
  counter++
  for (var i = 0; i < slideshowimage.length; i++) {
x=  slideshowimage[i].style.transform = 'translateX(' + (-size  * counter) + 'px)'
console.log(x);
}
})
console.log(document.getElementById('1').offsetWidth );
