const slideshow = document.querySelector('slideshow');
const slideshowImages = document.querySelectorAll('.slideshow img');
const slides = document.querySelector('#slides');

const next = document.querySelector('#next');
const prev = document.querySelector('#prev');

let counter = 1;
const size = slideshowImages[0].clientWidth;

slides.style.transform = 'translateX(' + (-size  * counter) + 'px)'


next.addEventListener('click', () => {
  if (counter >= slideshowImages.length - 1) return
  slides.style.transition = 'transform 1s ease-in-out'
  counter++
  slides.style.transform = 'translateX(' + (-size  * counter) + 'px)'
})


prev.addEventListener('click', () => {
  if (counter <= 0) return
  slides.style.transition = 'transform 1s ease-in-out'
  counter--
  slides.style.transform = 'translateX(' + (-size  * counter) + 'px)'

})

slides.addEventListener('transitionend', () => {
  if (slideshowImages[counter].id === 'lastclone' ) {
    console.log('eee');
    slides.style.transition = 'none'
    counter = slideshowImages.length - 2
  slides.style.transform = 'translateX(' + (-size  * counter) + 'px)'
  }
  if (slideshowImages[counter].id === 'firstclone' ) {
    console.log('eee');
    slides.style.transition = 'none'
    counter = slideshowImages.length - counter
  slides.style.transform = 'translateX(' + (-size  * counter) + 'px)'
  }
})
